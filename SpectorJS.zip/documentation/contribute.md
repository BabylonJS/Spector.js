[SpectorJS](../readme.md)
=========

## Contribute
We love the community :-)

We appreciate any feedback from bug to feature request on the repo as a Github issue.

If you are willing to add a feature and you would like to contribute, feel free to create a pull request.

We enjoy any contibutions from tests to Pull Requests.

PS: Please use TsLint locally before making a pull request and refer to the [build](build.md) documentation for more information.
