[SpectorJS](../readme.md)
=========

## Change Log
Please, find below the per release summary of the contribution added to the project per version. Each of the listed versions is having its corresponding tag in the repo.

## v0.9.1 Before V1
This release is addressing the latest issues before the V1 as well as embedding a shader editor:

- [Programmatic Capture do not open in a new tab](https://github.com/BabylonJS/Spector.js/issues/61)
- [Fix memory reporting of buffers](https://github.com/BabylonJS/Spector.js/issues/64)
- [Fix Capture Download in IE11](https://github.com/BabylonJS/Spector.js/issues/65)
- [Workaround perf and memory issue with a quick capture mode](https://github.com/BabylonJS/Spector.js/issues/67)
- [Fix Depth Range comparison](https://github.com/BabylonJS/Spector.js/issues/68)
- [Hook on WebVR Display RAF](https://github.com/BabylonJS/Spector.js/issues/62)
- [Fix Firefox Linux Charset Issue](https://github.com/BabylonJS/Spector.js/issues/70
- [Embedded Live Shader Editor](https://github.com/BabylonJS/Spector.js/blob/release/documentation/extension.md#shader-editor)

## v0.9.0 Fix and Style
This realease is meant to improve the overall stability and compatibility with other extension:

- [Workaround Firefox security issue relying on apply](https://github.com/BabylonJS/Spector.js/issues/37)
- Fix Uniform Array Capture
- [Allow Transient Context capture on reload](https://github.com/BabylonJS/Spector.js/issues/60)
- Add number of commands to capture on reload
- Integrate new logo
- Add more intuitive public programmatic APIs for capture.

## v0.3.0 Fix
This realease enables fixes a couple of reported issues:

- Fix memory usage report.
- Add MSAA render buffer capture.
- [Add Primitives Count per type](https://github.com/BabylonJS/Spector.js/issues/43).
- [Allow capture of float based width/height of FrameBuffer](https://github.com/BabylonJS/Spector.js/issues/52)
- [Fix uniform command Format](https://github.com/BabylonJS/Spector.js/issues/50)
- [Better Stacktrace support on Firefox](https://github.com/BabylonJS/Spector.js/issues/47)
- [Integrate Custom Marker](https://github.com/BabylonJS/Spector.js/issues/45)
- [Fix Enable/Disable vertex attrib command format](https://github.com/BabylonJS/Spector.js/issues/55)
- [Add Programmatic Capture](https://github.com/BabylonJS/Spector.js/issues/46)
- Add capture on Load in the extension.
- Open the extension in a new tab by default.
- [Shaders + properties are visible at the same time](https://github.com/BabylonJS/Spector.js/issues/59)
- [Introduce keyboard navigation](https://github.com/BabylonJS/Spector.js/issues/54)
- [Display SHADER_NAME in draw calls](https://github.com/BabylonJS/Spector.js/issues/53)
- [Add link to shaders in draw calls](https://github.com/BabylonJS/Spector.js/issues/53)

## v0.2.3 Typos and MultiTabs
This simply contains another quick fix concerning typos in readme and the extension popup. As a little bonus, you can now capture to a new tab.

## v0.2.2 Viewport and Scissor Commands format
This simply contains another quick fix concerning the command formatting used in spector. It now does not display WebglConstants for both ```viewport``` and ```scissor```.

## v0.2.1 Capture Number format
This simply contains a quick fix concerning the number formatting used in spector. It now does not display trailing 0 in case of integers.

## v0.2.0 Frame Analytics and Texture Inputs
This release includes new data around like number of commands, memory and more texture types support:

- Analyse capture and extract number of calls per commands.
- Analyse records and extract memory information (Frame and global).
- Display Buffer and Render Buffer information.
- [Shader Display Repeat issue of some sections.](https://github.com/BabylonJS/Spector.js/issues/34)
- [Invalid Attrib Location Crash](https://github.com/BabylonJS/Spector.js/issues/33)
- [Compressed textures information](https://github.com/BabylonJS/Spector.js/issues/32)

[View More...](changeLogs/v0.2.0.md)

## v0.1.2 First Stable
This release is the first stable release containing the Minimum Valuable Product.

- [Firefox Extension](https://addons.mozilla.org/en-US/firefox/addon/spector-js/)
- npm version fix
- [Mipped Textures](https://github.com/BabylonJS/Spector.js/issues/31)
- [UBO Values](https://github.com/BabylonJS/Spector.js/issues/30)
- [Unspyed Mode](https://github.com/BabylonJS/Spector.js/issues/29)

[View More...](changeLogs/v0.1.2.md)

## v0.0.11 Fix Release
This release is aimed to address a few of the first created bugs:

- [Texture Inputs](https://github.com/BabylonJS/Spector.js/issues/1)
- Shader Beautyfier by [Temechon](https://github.com/Temechon)
- UX improvments
- [Sketchfab WebGL2 Crash](https://github.com/BabylonJS/Spector.js/issues/13)

[View More...](changeLogs/v0.0.11.md)

## v0.0.10 Initial Release
This is the first public release available. It conatains all the basic structure of the project and browser extension.

- Capture Framework.
- Embedded UI with Capture and Result View.
- Loose coupling View/Backend to enhance the reusability of components.
- WebGL 1/2 Supports.
- NPM package.
- Chrome, Firefox, and Edge Extension.

[View More...](changeLogs/v0.0.10.md)