namespace SPECTOR {
    export interface ICanvasCapture {
        width: number;
        height: number;
        clientWidth: number;
        clientHeight: number;
        browserAgent: string;
    }
}
