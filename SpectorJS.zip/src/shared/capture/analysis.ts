namespace SPECTOR {
    export interface IAnalysis {
        analyserName: string;
        [key: string]: any;
    }
}
